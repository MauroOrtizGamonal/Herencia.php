<?php

class Cliente{
    //propiedad atributos y campos
    public string $nombre;
    private string $ciudad;
    public float $presupuesto;

    //constructor
    public function __construct(string $nombre,string $ciudad,float $presupuesto){

        $this->nombre=$nombre;
        $this->ciudad=$ciudad;
        $this->presupuesto=$presupuesto;
    }
    //getters-setters
    //funcionalidad encapsulamiento
    //update
    public function setCiudad(string $ciudad){
        $this->ciudad=$ciudad;
    }
    //resto de metodos
    public function fichaCliente(){
        echo("<p>Datos del cliente: </p>");
        echo("<p>Nombre: ".$this->nombre."</p>");
        echo("<p>Ciudad: ".$this->ciudad."</p>");
        echo("<p>Presupuesto: ".$this->presupuesto."</p>");
    }
}