<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Herencia en PHP</h2>
    <?php
    require_once('cliente.php');
    require_once('hija.php');
    $cliente1=new Cliente("repsol","málaga",123.95);
    $cliente1->fichaCliente();
    $cliente1->setCiudad("zaragoza");
    $cliente1->fichaCliente();
    echo("<hr>");
    $hija1=new Hija();
    $hija1->saludarHija();
    $hija1->saludarPadre();
    $padre1=new Padre();
    $padre1->saludarPadre();
    $hija1->saludarHija();
    ?>
</body>
</html>
