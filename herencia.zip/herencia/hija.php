<?php
require_once('padre.php');
class Hija extends Padre{
    public function saludarHija(){
        echo("<p>Hola, desde la clase hija</p>");
    }

}