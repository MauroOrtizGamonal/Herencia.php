<?php
class Padre{
    public function saludarPadre(){
        echo("<p>Hola, desde la clase padre</p>");
    }

}